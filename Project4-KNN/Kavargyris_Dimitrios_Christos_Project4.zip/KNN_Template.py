# =============================================================================
# HOMEWORK 4 - INSTANCE-BASED LEARNING
# K-NEAREST NEIGHBORS TEMPLATE
# Complete the missing code by implementing the necessary commands.
# For ANY questions/problems/help, email: arislaza@csd.auth.gr
# =============================================================================

# import the KNeighborsClassifier
# if you want to do the hard task, also import the KNNImputer
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score


# Import the titanic dataset
# Decide which features you want to use (some of them are useless, ie PassengerId).
#
# Feature 'Sex': because this is categorical instead of numerical, KNN can't deal with it, so drop it
# Note: another solution is to use one-hot-encoding, but it's out of the scope for this exercise.
#
# Feature 'Age': because this column contains missing values, KNN can't deal with it, so drop it
# If you want to do the harder task, don't drop it.
#
# =============================================================================
titanic = pd.read_csv('titanic.csv')
titanic.drop(['Sex','Age','Cabin','Name','Ticket'], inplace=True,axis=1)
#print(titanic.to_string())

# Normalize feature values using MinMaxScaler
# Fit the scaler using only the train data
# Transform both train and test data.
# =============================================================================
# split into train test sets

X = titanic.iloc[:, np.r_[1,3,4,5]]
y = titanic.iloc[:, 2]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25)
scaler = MinMaxScaler()
scaler.fit(X_train)

X_train = scaler.transform(X_train)
X_test = scaler.transform(X_test)

# Do the following only if you want to do the hard task.
#
# Perform imputation for completing the missing data for the feature
# 'Age' using KNNImputer. 
# As always, fit on train, transform on train and test.
#
# Note: KNNImputer also has a n_neighbors parameter. Use n_neighbors=3.
# =============================================================================
#imputer =



# Create your KNeighborsClassifier models for different combinations of parameters
# Train the model and predict. Save the performance metrics.
# =============================================================================

classifier = KNeighborsClassifier(n_neighbors=2, weights='uniform', p=3, metric='minkowski')
classifier.fit(X_train, y_train)

y_pred = classifier.predict(X_test)

print("Recall score:", recall_score(y_test, y_pred,average='macro',zero_division=1))
print("Precision score:", precision_score(y_test, y_pred, average='macro',zero_division=1))
print("Accuracy score:", accuracy_score(y_test, y_pred))
print("F1 score:", f1_score(y_test, y_pred, average='macro'))



# Plot the F1 performance results for any combination οf parameter values of your choice.
# If you want to do the hard task, also plot the F1 results with/without imputation (in the same figure)

# =============================================================================
n_neighbors = 200
batch_size = [] * 200
f1 = []
best_f1 = 0

for i in range(n_neighbors):
    batch_size.append(i+1)
    classifier = KNeighborsClassifier(n_neighbors=i+1, weights='distance', p=1, metric='minkowski')
    classifier.fit(X_train, y_train)
    y_pred = classifier.predict(X_test)
    n_f1 = f1_score(y_test,y_pred, average='macro')
    # print(n_f1)
    if n_f1 > best_f1:
        best_f1 = n_f1
        best_neighbor = i
    f1.append(n_f1)

print('Best f1 score:', best_f1 , 'with best neighbor:', best_neighbor)


plt.title('k-Nearest Neighbors (Weights = distance, Metric = minkowski, p = 1)')
plt.plot(batch_size,f1,'tab:grey',label='f1 score for n=200(without impute)')
plt.axis([0, 200, 0.85, 1])
plt.xlabel('Number of neighbors')
plt.ylabel('F1 score')
plt.legend()
plt.show()



